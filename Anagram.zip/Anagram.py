import sys
import json
from itertools import permutations
def handler(event, context):

# Python code to demonstrate
# to find all permutation of
# a given string
    #ini_str = event["queryStringParameters"]['tt']
    
    ini_str = str(event["queryStringParameters"]['queryparam1'])

# Initialising string
 

# Printing initial string
    print("Initial string", ini_str)

# Finding all permuatation
    permutation = [''.join(p) for p in permutations(ini_str)]
# Printing result
    
    #json_data = json.dumps(list(str(permutation))):
        # TODO: write code...)
    #return{"output": str(permutation) }
    
   # return { "test": str(permutation) }
    return {
        "isBase64Encoded": False,
        "statusCode": 200,
        "headers": {},
        "body": json.dumps({
            "greeting": permutation,
        })
    }